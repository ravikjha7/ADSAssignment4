import React from "react";
import Sidebar from "./Sidebar";
import "./Appbar.css";
import { Link } from "react-router-dom";
import { Icon } from "@material-ui/core";
import { AccountCircle } from "@material-ui/icons";
import { Col, Container, Navbar } from "react-bootstrap";
import useAuth from "../auth/useAuth";

import {
  CreateNewFolder,
  Dashboard,
  ExitToApp,
  MeetingRoom,
  MenuOpenRounded,
  MenuRounded,
} from "@material-ui/icons";

const SidedbarData = [

  {
    title: "Join Quiz",
    path: "/join-quiz",
    icon: <MeetingRoom />,
    CName: "nav-text",
  },
  {
    title: "Create Quiz",
    path: "/create-quiz",
    icon: <CreateNewFolder />,
    CName: "nav-text",
  },
];
const Appbar = () => {
  const { user } = useAuth();
  const { logOut } = useAuth();
  return (
    <Navbar fixed="top">
      <Container className="appbar">
        <Col className="slider">
          {/* <Sidebar /> */}
          <Link style={{fontFamily:'Open Sans', fontWeight: '700'}} to="/" className="home">
            ADS Assignment 4: Quiz App
          </Link>
        </Col>
        <Col className="appbar-user">
        {SidedbarData.map((item, index) => {
            return (
              <li key={index} className="nav-text">
                <Link to={item.path}>
                  <Icon>{item.icon}</Icon>
                  <span className="nav-item-title">{item.title}</span>
                </Link>
              </li>
            );
          })}
          <Icon className="icon">
            <AccountCircle onClick={() => {
                logOut();
              }} />
          </Icon>

          <p>
            <b>{user?.name}</b>
          </p>
        </Col>
      </Container>
    </Navbar>
  );
};

export default Appbar;
