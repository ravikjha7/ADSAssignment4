import React from "react";
import Loader from "react-loader-spinner";
import "./LoadingScreen.css";

const LoadingScreen = () => {
  return (
    <div className="loading">
      <h1 className="blue">
        <b>Quiz</b>iify
      </h1>

      <Loader color="#29455a" width={130} height={130} type="Circles" />
    </div>
  );
};
export default LoadingScreen;
