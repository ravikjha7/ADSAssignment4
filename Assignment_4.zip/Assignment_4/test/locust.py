from locust import HttpUser, between, task

import json

class WebsiteTasks(HttpUser):
    @task
    def join(self):
        data = {'quizid' : '58d69cba-aee7-4a0a-8dd4-2bdd2739b080'}
        self.client.post("/API/quizzes/join",data=json.dumps(data),headers={'content-type':'application/json'})
    @task
    def login(self):
        data = {'username' : 'b@gmail.com', 'password':'b123'}
        self.client.post("/API/quizzes/signin",data=json.dumps(data),headers={'content-type':'application/json'})